# DeltaLM Open Evolution Showcase — Full Reproducibility Pack

See [showcase README](showcase/README.md), [Chinese results](showcase/RESULTS_ZH.md), and `showcase/observatory.html`. The included `delta_core.py` is a local copy of the already-published kernel, not a new version.
